-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Dez 08, 2009 as 03:48 AM
-- Versão do Servidor: 5.1.36
-- Versão do PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `patients`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `dados_usuario`
--

CREATE TABLE IF NOT EXISTS `dados_usuario` (
  `usuario` varchar(8) NOT NULL,
  `dia` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `ano` int(11) NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `cidade` varchar(20) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `pais` varchar(20) NOT NULL,
  `humor` varchar(10) NOT NULL,
  `motivo` varchar(40) NOT NULL,
  `sobre` varchar(200) NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `dados_usuario`
--

INSERT INTO `dados_usuario` (`usuario`, `dia`, `mes`, `ano`, `sexo`, `cidade`, `estado`, `pais`, `humor`, `motivo`, `sobre`) VALUES
('teste', 5, 11, 1984, 'masculino', 'ribs', 'sp', 'brasil', 'bem', 'sei lah xP', 'hum.. sou só um teste! comprovado e aprovado! \n;) =X'),
('aldir', 30, 1, 1988, 'masculino', 'araras', 'SP', 'Brasil', 'muito bem', 'States', 'Phoda');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mapa_humor`
--

CREATE TABLE IF NOT EXISTS `mapa_humor` (
  `usuario` varchar(8) NOT NULL,
  `item1` varchar(40) NOT NULL,
  `item2` varchar(40) NOT NULL,
  `item3` varchar(40) NOT NULL,
  `item4` varchar(40) NOT NULL,
  `item5` varchar(40) NOT NULL,
  `item6` varchar(40) NOT NULL,
  `item7` varchar(40) NOT NULL,
  `item8` varchar(40) NOT NULL,
  `item9` varchar(40) NOT NULL,
  `item10` varchar(40) NOT NULL,
  `item11` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mapa_humor`
--

INSERT INTO `mapa_humor` (`usuario`, `item1`, `item2`, `item3`, `item4`, `item5`, `item6`, `item7`, `item8`, `item9`, `item10`, `item11`) VALUES
('teste', 'um pouco', 'sempre', 'nunca', 'maior parte', 'as vezes', 'nunca', 'nunca', 'as vezes', 'as vezes', 'nunca', 'nunca');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE IF NOT EXISTS `mensagens` (
  `usuario` varchar(8) NOT NULL,
  `remetente` varchar(8) NOT NULL,
  `lida` int(11) NOT NULL,
  `mensagem` varchar(80) NOT NULL,
  `data` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mensagens`
--

INSERT INTO `mensagens` (`usuario`, `remetente`, `lida`, `mensagem`, `data`) VALUES
('isa', 'aldir', 1, 'mensagem teste de aldir para isa xP', '2009-09-30'),
('isa', 'teste', 1, 'mensagem teste de.. teste.. uahuaha oi isa xP', '2009-10-01'),
('isa', 'aldir', 1, 'mensagem com data agora', '2009-10-02'),
('aldir', 'isa', 1, 'oi bobo', '2009-10-05'),
('isa', 'aldir', 1, 'teste 2', '2009-10-05'),
('isa', 'null', 1, 'recursao', '2009-10-06'),
('aldir', 'aldir', 1, 'mensagem recursiva', '2009-11-09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sintomas`
--

CREATE TABLE IF NOT EXISTS `sintomas` (
  `usuario` varchar(8) NOT NULL,
  `item1` varchar(40) NOT NULL,
  `item2` varchar(40) NOT NULL,
  `item3` varchar(40) NOT NULL,
  `item4` varchar(40) NOT NULL,
  `item5` varchar(40) NOT NULL,
  `item6` varchar(40) NOT NULL,
  `item7` varchar(40) NOT NULL,
  `item8` varchar(40) NOT NULL,
  `item9` varchar(40) NOT NULL,
  `item10` varchar(40) NOT NULL,
  `item11` varchar(40) NOT NULL,
  `item12` varchar(40) NOT NULL,
  `outros` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sintomas`
--

INSERT INTO `sintomas` (`usuario`, `item1`, `item2`, `item3`, `item4`, `item5`, `item6`, `item7`, `item8`, `item9`, `item10`, `item11`, `item12`, `outros`) VALUES
('aldir', 'Leve', 'Moderado', 'Nenhum', 'Nenhum', 'Severo', 'Moderado', 'Severo', 'Severo', 'Moderado', 'Nenhum', 'Moderado', 'Nenhum', 'nada'),
('teste', 'Severo', 'Nenhum', 'Nenhum', 'Nenhum', 'Nenhum', 'Severo', 'Nenhum', 'Nenhum', 'Moderado', 'Nenhum', 'Severo', 'Nenhum', 'sintominhas!');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario` varchar(8) NOT NULL,
  `senha` varchar(8) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `sobrenome` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `situacao` varchar(40) NOT NULL,
  `posicao` varchar(40) NOT NULL,
  `profile` int(11) NOT NULL,
  `sintomas` int(11) NOT NULL,
  `humor` int(11) NOT NULL,
  `ultimologin` date NOT NULL,
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`usuario`, `senha`, `nome`, `sobrenome`, `email`, `situacao`, `posicao`, `profile`, `sintomas`, `humor`, `ultimologin`) VALUES
('marcelo', 'senha', 'Marcelo', 'Silva', 'marcelo@hotmail.com', 'Bipolaridade', 'paciente', 0, 0, 0, '2009-11-20'),
('aldir', 'hendrix', 'Aldir Jose', 'Borelli Júnior', 'aldirjr@gmail.com', 'Depressão', 'paciente', 1, 1, 0, '2009-11-19'),
('isa', 'isa', 'Isabelle', 'Carvalho', 'isabelle_carvalho@hotmail.com', 'Ansiedade', 'paciente', 0, 0, 0, '2009-11-01'),
('maria', 'senha', 'Maria', 'Almeida', 'm_gatinha@bol.com.br', 'HIV', 'paciente', 0, 0, 0, '2009-11-01'),
('joao', 'teste', 'Joao', 'de Souza', 'joao_ds@hotmail.com', 'HIV', 'paciente', 0, 0, 0, '2009-11-01'),
('jose', 'teste', 'Jose Carlos', 'Pinto', 'josecarlosp2009@gotmail.com', 'HIV', 'paciente', 0, 0, 0, '2009-11-01'),
('teste', 'teste', 'Teste', 'da Silva', 'teste@dominio.com', 'Depressão', 'paciente', 1, 1, 1, '2009-11-20'),
('evandro', 'teste', 'Evando', 'Ruiz', 'evandro@ffclrp.usp.br', 'Nenhuma', 'membro da comunidade', 0, 0, 0, '2009-10-05');
