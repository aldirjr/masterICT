/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package enrolmentSystem;

import java.sql.ResultSet;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Aldir Jr
 */

public class usuario {

    private String usuario;
    private String senha;
    private String nome;
    private String sobrenome;
    private String situacao;
    private String posicao;
    private int idade;
    private String profile;

    public usuario(String usuario, String senha, String nome, String sobrenome, String situacao, String posicao, String profile){
        this.usuario=usuario;
        this.senha=senha;
        this.nome=nome;
        this.sobrenome=sobrenome;
        this.situacao=situacao;
        this.posicao=posicao;
        this.profile=profile;
    }

    public usuario(String usuario){
        this.usuario=usuario;
        int dia = 0,mes = 0,ano = 0;
        Date data;
        data = new Date();
        DAO dao = new DAO();
        ResultSet rs;
        try {
            dao.conectar();
            rs = dao.getResultSet("SELECT dia,mes,ano FROM dados_usuario WHERE usuario='"+this.usuario+"'");
            while(rs.next()){
                String diax = rs.getString("dia");
                String mesx = rs.getString("mes");
                String anox = rs.getString("ano");
                dia = Integer.parseInt(diax);
                mes = Integer.parseInt(mesx);
                ano = Integer.parseInt(anox);
            }
            dao.fecharConexao();
        }catch (Exception e){
            e.printStackTrace();
        }
        this.idade = data.getYear() + 1900 - ano;
        if(mes > data.getMonth() + 1)
            this.idade = this.idade-1;
        else
            if(mes == data.getMonth() + 1)
                if (dia > data.getDate())
                    this.idade = this.idade-1;
    }

    /*
    public usuario(String usuario, String senha){
        this.usuario=usuario;
        this.senha=senha;
    }
    */

    public String getUsuario(){
        return this.usuario;
    }

    public String getSenha(){
        return this.senha;
    }

    public String getNome(){
        return this.nome;
    }

    public String getSobrenome(){
        return this.sobrenome;
    }

    public String getSituacao(){
        return this.situacao;
    }

    public String getPosicao(){
        return this.posicao;
    }

    public String getProfile(){
        return this.profile;
    }

    public int getIdade(){
        return this.idade;
    }

    public static List getUsuarios(){
        DAO dao = new DAO();
        List l = new LinkedList();
        ResultSet rs;
        try {
            dao.conectar();
            rs = dao.getResultSet("SELECT usuario,senha,nome,sobrenome,situacao,posicao,profile FROM usuario ORDER BY usuario ASC");
            while(rs.next()){
                usuario u = new usuario(rs.getString("usuario"),rs.getString("senha"),rs.getString("nome"),rs.getString("sobrenome"),rs.getString("situacao"),rs.getString("posicao"),rs.getString("profile"));
                l.add(u);
            }
            dao.fecharConexao();
        }catch (Exception e){
            e.printStackTrace();
        }
        return l;
    }

/*
    public static List getUsuarios(){
        DAO dao = new DAO();
        List l = new LinkedList();
        ResultSet rs;
        try {
            dao.conectar();
            rs = dao.getResultSet("SELECT usuario,senha FROM usuario ORDER BY usuario ASC");
            while(rs.next()){
                usuario u = new usuario(rs.getString("usuario"),rs.getString("senha"));
                l.add(u);
            }
            dao.fecharConexao();
        }catch (Exception e){
            e.printStackTrace();
        }
        return l;
    }
 */
}