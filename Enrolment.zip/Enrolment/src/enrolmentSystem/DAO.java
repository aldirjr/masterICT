/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package enrolmentSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.sql.DataSource;

public class DAO {
    private Connection conexao = null;
    private DataSource ds = null;
    private boolean conectado = false;


    public DAO() {
    }

    public void conectar() throws Exception {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/patients",
        "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ResultSet getResultSet(String sql) throws Exception {
        ResultSet rs = null;
        Statement stmt = null;
        try {
            stmt = conexao.createStatement();
            rs = (ResultSet)stmt.executeQuery(sql);
        } catch(Exception e) {
            throw e;
        }
        return rs;
    }

    public boolean executarSQL(String sql) throws Exception{
        Statement stmt = null;
        boolean res = false;
        try {
            stmt = conexao.createStatement();
            res = stmt.execute(sql);
        } catch(Exception e) {
            throw e;
        }
        return res;
    }

    public void fecharConexao() throws Exception {
        try {
            if(conectado){
                conexao.close();
                conexao = null;
                ds = null;
                conectado = false;
            }
        } catch(Exception e){
            throw e;
        }
    }
}