-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Dez 08, 2009 as 03:48 AM
-- Versão do Servidor: 5.1.36
-- Versão do PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `patients`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `dados_usuario`
--

CREATE TABLE IF NOT EXISTS `Users_data` (
  `username` varchar(8) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `humor` varchar(10) NOT NULL,
  `reason` varchar(40) NOT NULL,
  `about` varchar(200) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `dados_usuario`
--

INSERT INTO `Users_data` (`user`, `day`, `month`, `year`, `sex`, `city`, `state`, `country`, `humor`, `reason`, `about`) VALUES
('teste', 5, 11, 1984, 'male', 'Newcastle', 'NSW', 'Australia', 'well', 'idk xP', 'hum.. just a test! \n;) =X'),
('aldir', 30, 1, 1988, 'male', 'sydney', 'NSW', 'Australia', 'very well', 'States', 'Good');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mapa_humor`
--

CREATE TABLE IF NOT EXISTS `Mapa_humor` (
  `usuario` varchar(8) NOT NULL,
  `item1` varchar(40) NOT NULL,
  `item2` varchar(40) NOT NULL,
  `item3` varchar(40) NOT NULL,
  `item4` varchar(40) NOT NULL,
  `item5` varchar(40) NOT NULL,
  `item6` varchar(40) NOT NULL,
  `item7` varchar(40) NOT NULL,
  `item8` varchar(40) NOT NULL,
  `item9` varchar(40) NOT NULL,
  `item10` varchar(40) NOT NULL,
  `item11` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mapa_humor`
--

INSERT INTO `Mapa_humor` (`usuario`, `item1`, `item2`, `item3`, `item4`, `item5`, `item6`, `item7`, `item8`, `item9`, `item10`, `item11`) VALUES
('teste', 'um pouco', 'sempre', 'nunca', 'maior parte', 'as vezes', 'nunca', 'nunca', 'as vezes', 'as vezes', 'nunca', 'nunca');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE IF NOT EXISTS `Messages_WSU` (
  `username` varchar(8) NOT NULL,
  `remetente` varchar(8) NOT NULL,
  `lida` int(11) NOT NULL,
  `mensagem` varchar(80) NOT NULL,
  `data` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `mensagens`
--

INSERT INTO `Messages_WSU` (`username`, `remetente`, `lida`, `mensagem`, `data`) VALUES
('isa', 'aldir', 1, 'mensagem teste de aldir para isa xP', '2009-09-30'),
('isa', 'teste', 1, 'mensagem teste de.. teste.. uahuaha oi isa xP', '2009-10-01'),
('isa', 'aldir', 1, 'mensagem com data agora', '2009-10-02'),
('aldir', 'isa', 1, 'oi bobo', '2009-10-05'),
('isa', 'aldir', 1, 'teste 2', '2009-10-05'),
('isa', 'null', 1, 'recursao', '2009-10-06'),
('aldir', 'aldir', 1, 'mensagem recursiva', '2009-11-09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sintomas`
--

CREATE TABLE IF NOT EXISTS `Sintomas` (
  `usuario` varchar(8) NOT NULL,
  `item1` varchar(40) NOT NULL,
  `item2` varchar(40) NOT NULL,
  `item3` varchar(40) NOT NULL,
  `item4` varchar(40) NOT NULL,
  `item5` varchar(40) NOT NULL,
  `item6` varchar(40) NOT NULL,
  `item7` varchar(40) NOT NULL,
  `item8` varchar(40) NOT NULL,
  `item9` varchar(40) NOT NULL,
  `item10` varchar(40) NOT NULL,
  `item11` varchar(40) NOT NULL,
  `item12` varchar(40) NOT NULL,
  `outros` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sintomas`
--

INSERT INTO `Sintomas` (`usuario`, `item1`, `item2`, `item3`, `item4`, `item5`, `item6`, `item7`, `item8`, `item9`, `item10`, `item11`, `item12`, `outros`) VALUES
('aldir', 'Leve', 'Moderado', 'Nenhum', 'Nenhum', 'Severo', 'Moderado', 'Severo', 'Severo', 'Moderado', 'Nenhum', 'Moderado', 'Nenhum', 'nada'),
('teste', 'Severo', 'Nenhum', 'Nenhum', 'Nenhum', 'Nenhum', 'Severo', 'Nenhum', 'Nenhum', 'Moderado', 'Nenhum', 'Severo', 'Nenhum', 'sintominhas!');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `User_WSU` (
  `username` varchar(8) NOT NULL,
  `password` varchar(8) NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `situation` varchar(40) NOT NULL,
  `position` varchar(40) NOT NULL,
  `profile` int(11) NOT NULL,
  `symptoms` int(11) NOT NULL,
  `humor` int(11) NOT NULL,
  `lastlogin` date NOT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `User_WSU` (`user`, `password`, `name`, `surname`, `email`, `situation`, `position`, `profile`, `symptoms`, `humor`, `lastlogin`) VALUES
('marcelo', 'senha', 'Marcelo', 'Silva', 'marcelo@hotmail.com', 'Bipolaridade', 'paciente', 0, 0, 0, '2009-11-20'),
('aldir', 'hendrix', 'Aldir Jose', 'Borelli Júnior', 'aldirjr@gmail.com', 'Depressão', 'paciente', 1, 1, 0, '2009-11-19'),
('isa', 'isa', 'Isabelle', 'Carvalho', 'isabelle_carvalho@hotmail.com', 'Ansiedade', 'paciente', 0, 0, 0, '2009-11-01'),
('maria', 'senha', 'Maria', 'Almeida', 'm_gatinha@bol.com.br', 'HIV', 'paciente', 0, 0, 0, '2009-11-01'),
('joao', 'teste', 'Joao', 'de Souza', 'joao_ds@hotmail.com', 'HIV', 'paciente', 0, 0, 0, '2009-11-01'),
('jose', 'teste', 'Jose Carlos', 'Pinto', 'josecarlosp2009@gotmail.com', 'HIV', 'paciente', 0, 0, 0, '2009-11-01'),
('teste', 'teste', 'Teste', 'da Silva', 'teste@dominio.com', 'Depressão', 'paciente', 1, 1, 1, '2009-11-20'),
('admin', 'admin', 'admName', 'admSurname', 'admin@admin.com', 'None', 'paiente', 1, 1, 1, '2009-11-20'),
('evandro', 'teste', 'Evando', 'Ruiz', 'evandro@ffclrp.usp.br', 'Nenhuma', 'membro da comunidade', 0, 0, 0, '2009-10-05');
