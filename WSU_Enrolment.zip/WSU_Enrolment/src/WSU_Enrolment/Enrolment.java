package WSU_Enrolment;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import WSU_Enrolment.DAO;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle.ComponentPlacement;

public class Enrolment extends JFrame {

	// Variables declaration
	private JPanel contentPane;
	private JTextField tfUnitId;
    private String complete;
    private String username;
    private String newMsgs;
    private JTextField tfGroupN;
	
    // Constructor
	public Enrolment() {
        this.username="";
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        updateLoginDate();
    }

    public void updateLoginDate() {
        DAO dao = new DAO();
        Date now = new Date();
        String format = "yyyy/MM/dd";
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        try {
            dao.connect();
            dao.executeSQL("UPDATE ESU_User SET lastLogin='"+formatter.format(now)+"' WHERE username='"+this.username+"'");
            dao.closeConnection();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
    
    public void numberMsgNRead(JTextField number, JLabel msgs) {
        int newMsgs = 0;
        DAO dao = new DAO();
        ResultSet rt = null;
        try {
            dao.connect();
            rt = dao.getResultSet("SELECT * FROM Messages_WSU WHERE username='"+this.username+"' AND lida='0'");
            while(rt.next()){
                newMsgs=newMsgs+1;
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        if (newMsgs == 1){
            msgs.setText("UNREAD MESSAGE");
        }
        number.setText(""+newMsgs+"");
    }

	/**
	 * Create the frame.
	 */
	public void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 562);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tfUnitId = new JTextField();
		tfUnitId.setBounds(208, 498, 129, 26);
		contentPane.add(tfUnitId);
		
		JLabel lblTypeTheUnit = new JLabel();
		lblTypeTheUnit.setText("Unit ID:");
		lblTypeTheUnit.setBounds(155, 503, 60, 16);
		contentPane.add(lblTypeTheUnit);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(778, 478));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 778, 478);
		contentPane.add(panel);
		 
		 JLabel lblEnrolment = new JLabel();
		lblEnrolment.setText("ENROLMENT");
		lblEnrolment.setFont(new Font("Dialog", Font.PLAIN, 36));
		
		JButton btnLogout = new JButton();
		btnLogout.setText("LOGOUT");
		
		JButton btnHome = new JButton("Home");
		
		JButton btnProfile = new JButton("Profile");
		
		JButton btnEnrolment = new JButton("Enrolment");
		
		JButton btnUnits = new JButton("Units");
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		JLabel lblUnitsEnroled = new JLabel("Units Enroled");
		lblUnitsEnroled.setForeground(new Color(0, 0, 139));
		lblUnitsEnroled.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JLabel lblUnitsAvailableTo = new JLabel("Units Available to Enrol");
		lblUnitsAvailableTo.setForeground(new Color(0, 0, 128));
		lblUnitsAvailableTo.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblEnrolment, GroupLayout.PREFERRED_SIZE, 276, GroupLayout.PREFERRED_SIZE)
							.addGap(314)
							.addComponent(btnLogout))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnHome, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnProfile, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnEnrolment, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnUnits, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(33)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(textPane, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblUnitsEnroled, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))
							.addGap(43)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUnitsAvailableTo, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
								.addComponent(textPane_1, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE))))
					.addGap(294))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(30)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(btnLogout)
						.addComponent(lblEnrolment))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(44)
							.addComponent(btnHome)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnProfile)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEnrolment)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnUnits))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUnitsAvailableTo, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblUnitsEnroled, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(textPane, GroupLayout.PREFERRED_SIZE, 329, GroupLayout.PREFERRED_SIZE)
								.addComponent(textPane_1, GroupLayout.PREFERRED_SIZE, 329, GroupLayout.PREFERRED_SIZE)))))
		);
		panel.setLayout(gl_panel);
		
		JLabel lblGroupNumber = new JLabel();
		lblGroupNumber.setText("Group number:");
		lblGroupNumber.setBounds(349, 503, 100, 16);
		contentPane.add(lblGroupNumber);
		
		tfGroupN = new JTextField();
		tfGroupN.setBounds(461, 498, 34, 26);
		contentPane.add(tfGroupN);
		
		JButton btnCancelEnrolment = new JButton("Cancel Enrolment");
		btnCancelEnrolment.setBounds(616, 498, 143, 29);
		contentPane.add(btnCancelEnrolment);
		
		JButton btnEnrol = new JButton("Enrol");
		btnEnrol.setBounds(507, 498, 97, 29);
		contentPane.add(btnEnrol);
	}
}
