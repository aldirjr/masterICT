package WSU_Enrolment;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.JTextPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.SwingConstants;

public class editUnits extends JFrame {

	private JPanel contentPane;
	private String[][]boardEntrances;
	private int totalEntrances;
	private String board;
	private String titleToBeUpdated;
	
	private JComboBox comboBoxSelected;
	private String unitSelected;
	private String groupSelected;
	
	private JTextField textCode;
	private JTextField textGroup;
	private JTextField textName;
	private JTextField textCredits;
	private JTextField textRequirement;
	private JTextField textGPA;
	private JTextField textProfessor;
	private JComboBox comboBoxSchedule;
	private JTextField textHStarts;
	private JTextField textHFinishes;
	
	private String[] unitAndId;
	

	
	/**
	 * Create the frame.
	 */
	public editUnits() {
		System.out.println("aqui ");
		initComponents();
	}
	
	public void fillForms() {
		System.out.println("aqui 5");
		updateBoard("load");
		/*
		textCode.setText(boardEntrances[item][0]);
		textCredits.setText(boardEntrances[item][1]);
		textInformation.setText(boardEntrances[item][2]);
		*/
		
	}
	
	public int loadCombo() {
		System.out.println("aqui 3");
		
		DAO dao = new DAO();
      
        ResultSet rs = null;
        String[] temp = new String[50];
        
        int i=0, totalItems = 0;
        
		try {
            dao.connect();
            
            //Update the Student Board and News Board
            rs = dao.getResultSet("SELECT DISTINCT unitID, groupId, unitName FROM ESU_Unit GROUP BY unitID, groupId, unitName");
            rs.getRow();
            while(rs.next()){
            		temp[i] = rs.getString("unitID") +"-"+rs.getString("groupId")+"-"+rs.getString("unitName");
                	i++;
            }
            totalItems = i;
            
            unitAndId = new String[i+2];
            unitAndId[0] = "Select...";
            unitAndId[1] = "New";
            
            for(int j=0;j<i;j++) {
            	unitAndId[j+2]=temp[j];
            }
            
            dao.closeConnection();
            System.out.println("aqui d");
        }
        catch(Exception e){
             e.printStackTrace();
        }
		
		return totalItems;
				
	}
	
	public void updateBoard(String command) {
		System.out.println("aqui 4");
		
		DAO dao = new DAO();
        ResultSet rs = null;
        try {
        	dao.connect();
        	// delete the unit
        	if (command.equals("delete")){
        		//dao.executeSQL("DELETE FROM ESU_BOARDS WHERE title = '"+titleToBeUpdated+"'");

        	}
        	else {
        		//create a new unit
        		if (command.equals("new")) {
        			//dao.executeSQL("INSERT INTO ESU_BOARDS (board, title, text, publication_date) VALUES ('"+board+"','"+textCode.getText()+"','"+textInformation.getText()+"','"+textCredits.getText()+"')");      
        		}
        		//update unit information
        		else{
        			if (command.equals("update")) {
        				dao.executeSQL("UPDATE ESU_Unit SET unitID="+textCode.getText()+", groupId ="+textGroup.getText()+", unitName ='"+textName.getText()+"', credits ="+textCredits.getText()+""
        						+ ", requirement ="+textRequirement.getText()+", GPAmin ="+textGPA.getText()+", professorName ='"+textProfessor.getText()+"', weekDay ='"+(String) comboBoxSchedule.getSelectedItem()+"'"
        						+ ", hourStart ="+textHStarts.getText()+", hourEnd='"+textHFinishes.getText()+"' WHERE unitName='"+titleToBeUpdated+"'");      

        			}
        			//load unit information
        			else
        			{
        				rs = dao.getResultSet("SELECT unitID,groupId,unitName,credits,requirement,GPAmin,professorname,weekDay,hourStart,hourEnd FROM ESU_Unit WHERE unitID = "+unitSelected+" AND groupId ="+groupSelected+"");
        				if (rs.next()) {
        					textCode.setText(rs.getString("unitId"));
        	        		textGroup.setText(rs.getString("groupId"));
        	        		textName.setText(rs.getString("unitName"));
        	        		textCredits.setText(rs.getString("credits"));
        	        		textRequirement.setText(rs.getString("requirement"));
        	        		textGPA.setText(rs.getString("GPAmin"));
        	        		textProfessor.setText(rs.getString("professorName"));
        	        		//comboBoxSchedule.setSelectedItem(rs.getString("weekDay"));
        	        		textHStarts.setText(rs.getString("hourStart"));
        	        		textHFinishes.setText(rs.getString("hourEnd"));
        				}
        			}
        		}
/*
        		JOptionPane.showMessageDialog(this,"The board has been updated","Updated",JOptionPane.INFORMATION_MESSAGE);
        		dao.closeConnection();
        		textCode.setText("");
        		textGroup.setText("");
        		textName.setText("");
        		textCredits.setText("");
        		textRequirement.setText("");
        		textGPA.setText("");
        		textProfessor.setText("");
        		comboBoxSchedule.setSelectedIndex(0);
        		textHStarts.setText("");
        		textHFinishes.setText("");

        		comboBoxSelected.setSelectedIndex(0);

        		updateNewState();
        		*/

        	}
        }
        catch(Exception e){
             e.printStackTrace();
        }
	}
	
private void updateNewState() {
		
		System.out.println("aqui 2");
		
		DAO dao = new DAO();
       
        ResultSet rs = null;
        int i=0;
        
        try {
            dao.connect();
            //Update the titles available
            rs = dao.getResultSet("SELECT title, publication_date, text FROM ESU_Boards WHERE board = '"+board+"'");
            while(rs.next()){        
            	boardEntrances[i][0]=rs.getString("title");
            	boardEntrances[i][1]=rs.getString("publication_date");
            	boardEntrances[i][2]=rs.getString("text");
                i++;              	
                totalEntrances = i;
            }   
            dao.closeConnection();
            
            String[] loadCombo = new String[totalEntrances+2];
            loadCombo[0] = "Select...";
    		loadCombo[1] = "New";
    		for (int j=0; j < totalEntrances; j++) {
    			loadCombo[j+2] = boardEntrances[j][0];
    		}
    		DefaultComboBoxModel model = new DefaultComboBoxModel(loadCombo);
    		comboBoxSelected.setModel(model);
    		
        }
        catch(Exception e){
             e.printStackTrace();
        }
	}
	
	public void cancelEdit() {
		this.dispose();
	}
	
	public void initComponents() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//Centralize screen
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		setBounds(100, 100, 420, 430);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUnits = new JLabel();
		lblUnits.setHorizontalAlignment(SwingConstants.CENTER);
		lblUnits.setText("Units");
		lblUnits.setFont(new Font("Dialog", Font.PLAIN, 36));
		lblUnits.setBounds(99, 6, 188, 43);
		contentPane.add(lblUnits);
		
		textCode = new JTextField();
		textCode.setEnabled(false);
		textCode.setColumns(10);
		textCode.setBounds(17, 128, 93, 26);
		contentPane.add(textCode);
		
		JLabel lblCode = new JLabel("Code");
		lblCode.setBounds(27, 110, 61, 16);
		contentPane.add(lblCode);
		
		JLabel lblCredits = new JLabel("Credits:");
		lblCredits.setBounds(316, 210, 49, 16);
		contentPane.add(lblCredits);
		
		textCredits = new JTextField();
		textCredits.setEnabled(false);
		textCredits.setColumns(10);
		textCredits.setBounds(321, 227, 31, 26);
		contentPane.add(textCredits);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelEdit();
			}
		});
		btnCancel.setBounds(194, 367, 93, 29);
		contentPane.add(btnCancel);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateBoard("save");
			}
		});
		btnSave.setBounds(290, 367, 93, 29);
		contentPane.add(btnSave);
		
		System.out.println("aqui a");
		
		loadCombo();
		
		System.out.println("aqui c");
		
		comboBoxSelected = new JComboBox(unitAndId);
		
		comboBoxSelected.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch (comboBoxSelected.getSelectedIndex()) {
				case 0:
					break;
				case 1:
					System.out.println("New");
					textCode.setEnabled(true);
					textCredits.setEnabled(true);
					//titleToBeUpdated = "new";
					break;
				default:
					String[] tokens = ((String) comboBoxSelected.getSelectedItem()).split("-",5);
					unitSelected = tokens[0];
					groupSelected = tokens[1];
					updateBoard("load");// comboBoxSelected.getSelectedIndex()-2);
					// -2 because first 2 entrances are: Select and New;
					//textCode.setEnabled(true);
					//textCredits.setEnabled(true);
					//titleToBeUpdated = (String) comboBoxSelected.getSelectedItem();
					break;
				}
				
			}
		});
		comboBoxSelected.setBounds(17, 61, 385, 27);
		contentPane.add(comboBoxSelected);
		
		System.out.println("aqui b");
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateBoard("delete");
			}
		});
		btnDelete.setBounds(99, 367, 93, 29);
		contentPane.add(btnDelete);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(135, 110, 61, 16);
		contentPane.add(lblName);
		
		textName = new JTextField();
		textName.setEnabled(false);
		textName.setColumns(10);
		textName.setBounds(125, 128, 277, 26);
		contentPane.add(textName);
		
		JLabel lblMinGpa = new JLabel("min GPA:");
		lblMinGpa.setBounds(131, 166, 61, 16);
		contentPane.add(lblMinGpa);
		
		textGPA = new JTextField();
		textGPA.setEnabled(false);
		textGPA.setColumns(10);
		textGPA.setBounds(194, 161, 31, 26);
		contentPane.add(textGPA);
		
		JLabel lblUnitRequirement = new JLabel("Requirement:");
		lblUnitRequirement.setBounds(226, 166, 86, 16);
		contentPane.add(lblUnitRequirement);
		
		textRequirement = new JTextField();
		textRequirement.setEnabled(false);
		textRequirement.setColumns(10);
		textRequirement.setBounds(316, 161, 86, 26);
		contentPane.add(textRequirement);
		
		JLabel lblProfessor = new JLabel("Professor");
		lblProfessor.setBounds(27, 210, 61, 16);
		contentPane.add(lblProfessor);
		
		comboBoxSchedule = new JComboBox(new Object[]{});
		comboBoxSchedule.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"}));
		comboBoxSchedule.setBounds(17, 294, 145, 27);
		contentPane.add(comboBoxSchedule);
		
		JLabel lblSchedule = new JLabel("Schedule");
		lblSchedule.setBounds(27, 277, 61, 16);
		contentPane.add(lblSchedule);
		
		JLabel lblHourStart = new JLabel("Hour Starts");
		lblHourStart.setBounds(184, 277, 83, 16);
		contentPane.add(lblHourStart);
		
		textHStarts = new JTextField();
		textHStarts.setEnabled(false);
		textHStarts.setColumns(10);
		textHStarts.setBounds(174, 295, 93, 26);
		contentPane.add(textHStarts);
		
		JLabel lblHourFinish = new JLabel("Hour Finishes");
		lblHourFinish.setBounds(279, 277, 90, 16);
		contentPane.add(lblHourFinish);
		
		textHFinishes = new JTextField();
		textHFinishes.setEnabled(false);
		textHFinishes.setColumns(10);
		textHFinishes.setBounds(276, 295, 93, 26);
		contentPane.add(textHFinishes);
		
		textGroup = new JTextField();
		textGroup.setEnabled(false);
		textGroup.setColumns(10);
		textGroup.setBounds(80, 161, 31, 26);
		contentPane.add(textGroup);
		
		JLabel lblGroup = new JLabel("Group:");
		lblGroup.setBounds(27, 166, 49, 16);
		contentPane.add(lblGroup);
		
		textProfessor = new JTextField();
		textProfessor.setBounds(17, 227, 270, 26);
		contentPane.add(textProfessor);
		textProfessor.setColumns(10);
		
	}
}
