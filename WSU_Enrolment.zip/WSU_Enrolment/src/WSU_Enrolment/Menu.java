package WSU_Enrolment;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import WSU_Enrolment.DAO;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu extends JFrame {

	// Variables declaration
	private JPanel contentPane;
	private JTextPane board1;
	private JTextPane board2;
    private String complete;
    private String username;
    private String newMsgs;
	
    // Constructor
	public Menu(String username) {
        this.username=username;
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        updateLastLogin();
    }

	//Update the last login user made in the system
	public void updateLastLogin() {
        DAO dao = new DAO();
        Date now = new Date();
        String format = "yyyy/MM/dd";
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        try {
            dao.connect();
            //Update the last login user made
            dao.executeSQL("UPDATE ESU_User SET lastLogin='"+formatter.format(now)+"' WHERE username='"+this.username+"'");
            dao.closeConnection();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
	
	public void updateBoards(JTextPane panelStu, JTextPane panelNews) {
        DAO dao = new DAO();
        Date now = new Date();
        ResultSet rs = null;
        String board1="", board2="";
        try {
            dao.connect();
            //Update the last login user made
            rs = dao.getResultSet("SELECT board, title, publication_date, text FROM ESU_Boards");
            while(rs.next()){
            	System.out.println(rs.getString("board"));
                if (rs.getString("board").equalsIgnoreCase("Student")) {
                	System.out.println("aqui");
                	//System.out.println(rs.getString("title"));
                	//System.out.println(rs.getString("publication_date"));
                	board1 = board1 + rs.getString("title") +" / "+rs.getString("publication_date")+"\n"
                			+ rs.getString("text")+"\n\n";
                }
                else {
                	board2 = board2 + rs.getString("title") +" / "+rs.getString("publication_date")+"\n"
                			+ rs.getString("text")+"\n\n";
                }
                //System.out.println(board1);
                //System.out.println(board2);
                panelStu.setText(board1);
                panelNews.setText(board2);
            }
            dao.closeConnection();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
	
	/*rs = dao.getResultSet("SELECT day,month,year FROM ESU_User_data WHERE username='"+this.username+"'");
            while(rs.next()){
                String dayx = rs.getString("day");
                String monthx = rs.getString("month");
                String yearx = rs.getString("year");
                day = Integer.parseInt(dayx);
                month = Integer.parseInt(monthx);
                year = Integer.parseInt(yearx);
            }
            */
    
    public void numberMsgNRead(JTextField number, JLabel msgs) {
        int newMsgs = 0;
        DAO dao = new DAO();
        ResultSet rt = null;
        try {
            dao.connect();
            rt = dao.getResultSet("SELECT * FROM ESU_Messages WHERE username='"+this.username+"' AND lida='0'");
            while(rt.next()){
                newMsgs=newMsgs+1;
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        if (newMsgs == 1){
            msgs.setText("UNREAD MESSAGE");
        }
    }
    
    public void openProfile() {
    	this.setVisible(false);
        JFrame enrolment=new Enrolment();
        enrolment.setVisible(true);
    }
    
    public void logoff() {
    	this.setVisible(false);
        JFrame login=new login();
        login.setVisible(true);
    }

	/**
	 * Create the frame.
	 */
	public void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 562);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel lblAttentionItIs = new JLabel();
		lblAttentionItIs.setForeground(Color.RED);
		lblAttentionItIs.setText("ATTENTION! IT IS TIME TO ENROL IN UNITS FOR THE NEXT SESSION!");
		lblAttentionItIs.setBounds(319, 504, 432, 16);
		contentPane.add(lblAttentionItIs);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(778, 478));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 778, 478);
		contentPane.add(panel);
		 
		 JLabel label_2 = new JLabel();
		label_2.setText("MENU");
		label_2.setFont(new Font("Dialog", Font.PLAIN, 36));
		
		JLabel label_3 = new JLabel("Student board");
		label_3.setForeground(new Color(0, 0, 139));
		label_3.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JLabel label_4 = new JLabel("Events / NEWS");
		label_4.setForeground(new Color(0, 0, 128));
		label_4.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JLabel label_5 = new JLabel();
		label_5.setText("WELCOME");
		label_5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		
		JLabel label_6 = new JLabel("New label");
		label_6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label_6.setText(username.toUpperCase());
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		
		JButton btnLogout = new JButton();
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logoff();
			}
		});
		btnLogout.setText("LOGOUT");
		
		JButton btnProfile = new JButton("Profile");
		
		JButton btnEnrolment = new JButton("Enrolment");
		btnEnrolment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openProfile();
			}
		});
		
		JButton btnUnits = new JButton("Units");
		 
		JTextPane tpStudentBoard = new JTextPane();
		tpStudentBoard.setEditable(false);
		tpStudentBoard.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		JTextPane tpEventsNews = new JTextPane();
		tpEventsNews.setEditable(false);
		tpEventsNews.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		updateBoards(tpStudentBoard, tpEventsNews);
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_panel.createSequentialGroup()
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
								.addGap(169)
								.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))
							.addGroup(gl_panel.createSequentialGroup()
								.addComponent(label_5)
								.addGap(18)
								.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE)
								.addGap(385)
								.addComponent(btnLogout)))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(btnProfile, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnEnrolment, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnUnits, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(30)
							.addComponent(tpStudentBoard, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)
							.addGap(43)
							.addComponent(tpEventsNews, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)))
					.addGap(43))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(30)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE, false)
						.addComponent(label_5)
						.addComponent(btnLogout)
						.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
					.addGap(16)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_2)
							.addComponent(label_3))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(18)
							.addComponent(btnProfile)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEnrolment)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnUnits))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(6)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(tpEventsNews, GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.RELATED))
								.addComponent(tpStudentBoard, GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE))))
					.addGap(21))
		);
		panel.setLayout(gl_panel);
	}
}
