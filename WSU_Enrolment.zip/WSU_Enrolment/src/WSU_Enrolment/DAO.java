/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package WSU_Enrolment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.sql.DataSource;

public class DAO {
    private Connection conexion = null;
    private DataSource ds = null;
    private boolean conected = false;


    public DAO() {
    }

    public void connect() throws Exception {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/WSU_PP_FinalProject",
        "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ResultSet getResultSet(String sql) throws Exception {
        ResultSet rs = null;
        Statement stmt = null;
        try {
            stmt = conexion.createStatement();
            rs = (ResultSet)stmt.executeQuery(sql);
        } catch(Exception e) {
            throw e;
        }
        return rs;
    }

    public boolean executeSQL(String sql) throws Exception{
        Statement stmt = null;
        boolean res = false;
        try {
            stmt = conexion.createStatement();
            res = stmt.execute(sql);
        } catch(Exception e) {
            throw e;
        }
        return res;
    }

    public void closeConnection() throws Exception {
        try {
            if(conected){
                conexion.close();
                conexion = null;
                ds = null;
                conected = false;
            }
        } catch(Exception e){
            throw e;
        }
    }
}