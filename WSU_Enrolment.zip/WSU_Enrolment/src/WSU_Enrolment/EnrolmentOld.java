package WSU_Enrolment;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import WSU_Enrolment.DAO;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EnrolmentOld extends JFrame {

	// Variables declaration
	private JPanel contentPane;
	private JTextField tfUnitId;
    private String complete;
    private String username;
    private String newMsgs;
    private JTextField tfGroupN;
    private User currentUser;
	private JFrame pMenu;
    
    // Constructor
	public EnrolmentOld(JFrame menu, User currentUser) {
		
    	this.currentUser = currentUser;
        this.username="";
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Centralize screen
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        
        pMenu = menu;
		menu.setVisible(false);
        this.setVisible(true);
        updateLoginDate();
    }

    public void updateLoginDate() {
        DAO dao = new DAO();
        Date now = new Date();
        String format = "yyyy/MM/dd";
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        try {
            dao.connect();
            dao.executeSQL("UPDATE ESU_User SET lastLogin='"+formatter.format(now)+"' WHERE username='"+this.username+"'");
            dao.closeConnection();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
    
  //Connect to the Database and Update the name and board in the GUI, and user's last login in the Database
  	private void connectToDB(JTextPane panelEnroled, JTextPane panelAvailable) {
  		
  		DAO dao = new DAO();
          ResultSet rs1 = null, rs2 = null;
          String board1="", board2="";
          int tCredits=0;
          try {
              dao.connect();
              
              //get Units Student Enrolled
              rs1 = dao.getResultSet("SELECT u.unitID, u.group, u.unitName, u.professorName, u.credits"
              		+ ", u.weekDay, u.hourStart, u.hourEnd"
              		+ " FROM ESU_UNIT u INNER JOIN ESU_ENROL e ON u.unitID = e.unitID"
              		+ " WHERE e.studentUserName = '"+currentUser.getUsername()+"' AND e.unitID = u.unitID AND e.group = u.group");
              rs2 = dao.getResultSet("SELECT u.unitID, u.group, u.unitName, u.professorName"
                		+ " FROM ESU_UNIT u INNER JOIN ESU_ENROL e ON u.unitID = e.unitID"
                		+ " WHERE e.studentUserName = '"+currentUser.getUsername()+"' AND e.unitID = u.unitID AND e.group = u.group");
              //Update the Boards: Units Enroled and Units Available
              while(rs1.next()){
                  	board1 = board1 + "UNIT ID: "+rs1.getString("u.unitID") +" / Group: "+rs1.getString("u.group")+"\n"
                  			+ rs1.getString("u.unitName")+"\nCredits: "+ rs1.getString("u.credits")
                  			+"\n"+ rs1.getString("u.professorName")+"\n"+ rs1.getString("u.weekDay") +"\n"
                  					+ rs1.getString("u.hourStart")+" - "+ rs1.getString("u.hourEnd") +"\n\n";
                  	tCredits += Integer.parseInt(rs1.getString("u.credits"));
              }
              board1 += "\n\nTOTAL: " + tCredits + " Credits";
              panelEnroled.setText(board1);
              while(rs2.next()){
                	board2 = board2 + "UNIT ID: "+rs2.getString("u.unitID") +" / Group: "+rs2.getString("u.group")+"\n"
                			+ rs2.getString("u.unitName")+"\n"+ rs2.getString("u.professorName")+"\n\n";
            }
            panelEnroled.setText(board1);
              
            dao.closeConnection();
          }
          catch(Exception e){
               e.printStackTrace();
          }
  	}
    
    //Confirm enrolment in Unit/Group
    private void confirmEnrolment(String unitIDS, String groupNS) throws ParseException {
    	int unitId = Integer.parseInt(unitIDS);
    	int groupN = Integer.parseInt(groupNS);
    	
    	//dont forget to check number os students enroled! do no trepass limit
    	
    	
    	//to compare times
    	String startTime = "10:00";
        String endTime = "12:00";
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Date d1 = sdf.parse(startTime);
        Date d2 = sdf.parse(endTime);
        long elapsed = d2.getTime() - d1.getTime(); 
        System.out.println(elapsed);
        
    }
    
  //Cancel enrolment in Unit/Group
    private void cancelEnrolment(String unitIDS, String groupNS) {
    	int unitId = Integer.parseInt(unitIDS);
    	int groupN = Integer.parseInt(groupNS);
    }
    
    
    
    public void goBackMenu() {
    	this.setVisible(false);
    	pMenu.setVisible(true);
    }
    
    public void logoff() {
    	this.dispose();
        JFrame login=new login();
        login.setVisible(true);
    }

	/**
	 * Create the frame.
	 */
	public void initComponents() {
		setBounds(100, 100, 778, 562);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tfUnitId = new JTextField();
		tfUnitId.setBounds(208, 498, 129, 26);
		contentPane.add(tfUnitId);
		
		JLabel lblTypeTheUnit = new JLabel();
		lblTypeTheUnit.setText("Unit ID:");
		lblTypeTheUnit.setBounds(155, 503, 60, 16);
		contentPane.add(lblTypeTheUnit);
		
		JPanel panelEnrolment = new JPanel();
		panelEnrolment.setPreferredSize(new Dimension(778, 478));
		panelEnrolment.setBackground(Color.LIGHT_GRAY);
		panelEnrolment.setBounds(0, 0, 778, 478);
		contentPane.add(panelEnrolment);
		 
		 JLabel lblEnrolment = new JLabel();
		lblEnrolment.setText("ENROLMENT");
		lblEnrolment.setFont(new Font("Dialog", Font.PLAIN, 36));
		
		JButton btnLogout = new JButton();
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logoff();
			}
		});
		btnLogout.setText("LOGOUT");
		
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBackMenu();
				
			}
		});
		
		JButton btnProfile = new JButton("Profile");
		
		JButton btnEnrolment = new JButton("EnrolmentOld");
		btnEnrolment.setEnabled(false);
		btnEnrolment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton btnUnits = new JButton("Units");
		
		JLabel lblUnitsEnroled = new JLabel("Units Enroled");
		lblUnitsEnroled.setForeground(new Color(0, 0, 139));
		lblUnitsEnroled.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JTextPane tpUnitsEnroled = new JTextPane();
		tpUnitsEnroled.setEditable(false);
		tpUnitsEnroled.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		JScrollPane sp = new JScrollPane(tpUnitsEnroled, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		JLabel lblUnitsAvailableTo = new JLabel("Units Available to Enrol");
		lblUnitsAvailableTo.setForeground(new Color(0, 0, 128));
		lblUnitsAvailableTo.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JTextPane tpUnitsAvailable = new JTextPane();
		tpUnitsAvailable.setEditable(false);
		tpUnitsAvailable.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		JScrollPane sp2 = new JScrollPane(tpUnitsAvailable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		GroupLayout gl_panelEnrolment = new GroupLayout(panelEnrolment);
		gl_panelEnrolment.setHorizontalGroup(
			gl_panelEnrolment.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panelEnrolment.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panelEnrolment.createSequentialGroup()
							.addComponent(lblEnrolment, GroupLayout.PREFERRED_SIZE, 276, GroupLayout.PREFERRED_SIZE)
							.addGap(314)
							.addComponent(btnLogout))
						.addGroup(gl_panelEnrolment.createSequentialGroup()
							.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnHome, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnProfile, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnEnrolment, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnUnits, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(33)
							.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING)
								.addComponent(tpUnitsEnroled, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblUnitsEnroled, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))
							.addGap(43)
							.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUnitsAvailableTo, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
								.addComponent(tpUnitsAvailable, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE))))
					.addGap(294))
		);
		gl_panelEnrolment.setVerticalGroup(
			gl_panelEnrolment.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panelEnrolment.createSequentialGroup()
					.addGap(30)
					.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING)
						.addComponent(btnLogout)
						.addComponent(lblEnrolment))
					.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panelEnrolment.createSequentialGroup()
							.addGap(44)
							.addComponent(btnHome)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnProfile)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEnrolment)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnUnits))
						.addGroup(gl_panelEnrolment.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUnitsAvailableTo, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblUnitsEnroled, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panelEnrolment.createParallelGroup(Alignment.LEADING)
								.addComponent(tpUnitsEnroled, GroupLayout.PREFERRED_SIZE, 329, GroupLayout.PREFERRED_SIZE)
								.addComponent(tpUnitsAvailable, GroupLayout.PREFERRED_SIZE, 329, GroupLayout.PREFERRED_SIZE)))))
		);
		panelEnrolment.setLayout(gl_panelEnrolment);
		
		JLabel lblGroupNumber = new JLabel();
		lblGroupNumber.setText("Group number:");
		lblGroupNumber.setBounds(349, 503, 100, 16);
		contentPane.add(lblGroupNumber);
		
		tfGroupN = new JTextField();
		tfGroupN.setBounds(461, 498, 34, 26);
		contentPane.add(tfGroupN);
		
		JButton btnCancelEnrolment = new JButton("Cancel EnrolmentOld");
		btnCancelEnrolment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelEnrolment(tfUnitId.getText(), tfGroupN.getText());
			}
		});
		btnCancelEnrolment.setBounds(616, 498, 143, 29);
		contentPane.add(btnCancelEnrolment);
		
		JButton btnEnrol = new JButton("Enrol");
		btnEnrol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					confirmEnrolment(tfUnitId.getText(), tfGroupN.getText());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnEnrol.setBounds(507, 498, 97, 29);
		contentPane.add(btnEnrol);
		
		connectToDB(tpUnitsEnroled, tpUnitsAvailable);
		
	}
}
