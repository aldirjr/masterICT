package WSU_Enrolment;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.JTextPane;

public class editBoard2 extends JFrame {

	private JPanel contentPane;
	private JTextField textTitle;
	private JTextField textDate;
	private JTextPane textInformation;
	String[][]boardEntrances;
	int totalEntrances;
	String board;


	/**
	 * Create the frame.
	 */
	public editBoard2(String[][] boardItems, int itemSize, int boardNumber) {
		boardEntrances = boardItems;
		totalEntrances = itemSize;
		if (boardNumber == 1) {
			board = "Student";
		}
		else
			board = "News";
		initComponents();
	}
	
	public void fillForms(int item) {
		textTitle.setText(boardEntrances[item][0]);
		textDate.setText(boardEntrances[item][1]);
		textInformation.setText(boardEntrances[item][2]);
	}
	
	public void updateBoard() {
		DAO dao = new DAO();
        Date now = new Date();
        String format = "yyyy/MM/dd";
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        ResultSet rs = null;
        
        try {
            dao.connect();
            //Update the last login user made
            dao.executeSQL("UPDATE ESU_BOARDS SET title='"+textTitle+"', publication_date='"+textDate+"', text='"+textInformation+"' WHERE board='"+board+"'");      
            dao.closeConnection();
        }
        catch(Exception e){
             e.printStackTrace();
        }
	}
	
	
	public void cancelEdit() {
		this.dispose();
	}
	
	public void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 430);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel();
		label.setText("Edit board");
		label.setFont(new Font("Dialog", Font.PLAIN, 36));
		label.setBounds(99, 6, 188, 43);
		contentPane.add(label);
		
		textTitle = new JTextField();
		textTitle.setEnabled(false);
		textTitle.setColumns(10);
		textTitle.setBounds(17, 128, 262, 26);
		contentPane.add(textTitle);
		
		JLabel label_1 = new JLabel("Title");
		label_1.setBounds(27, 110, 61, 16);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Date");
		label_2.setBounds(27, 166, 61, 16);
		contentPane.add(label_2);
		
		textDate = new JTextField();
		textDate.setEnabled(false);
		textDate.setColumns(10);
		textDate.setBounds(17, 184, 130, 26);
		contentPane.add(textDate);
		
		JLabel label_3 = new JLabel("Information");
		label_3.setBounds(27, 222, 93, 16);
		contentPane.add(label_3);
		
		JButton button = new JButton("Cancel");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelEdit();
			}
		});
		button.setBounds(194, 367, 93, 29);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Save");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateBoard();
			}
		});
		button_1.setBounds(290, 367, 93, 29);
		contentPane.add(button_1);
		
		textInformation = new JTextPane();
		textInformation.setEnabled(false);
		textInformation.setBounds(17, 247, 385, 116);
		contentPane.add(textInformation);
		
		
		String[] loadCombo = new String[totalEntrances+2];
		loadCombo[0] = "Select...";
		loadCombo[1] = "New";
		for (int i=0; i < totalEntrances; i++) {
			loadCombo[i+2] = boardEntrances[i][0];
		}
		
		JComboBox comboBox = new JComboBox(loadCombo);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch (comboBox.getSelectedIndex()) {
				case 0:
					break;
				case 1:
					System.out.println("New");
					textTitle.setEnabled(true);
					textDate.setEnabled(true);
					textInformation.setEnabled(true);
					break;
				default:
					fillForms(comboBox.getSelectedIndex()-2);
					// -2 because first 2 entrances are: Select and New;
					textTitle.setEnabled(true);
					textDate.setEnabled(true);
					textInformation.setEnabled(true);
					break;
				}
				
			}
		});
		comboBox.setBounds(17, 61, 270, 27);
		contentPane.add(comboBox);
		
	}
}
