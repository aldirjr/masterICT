package WSU_Enrolment;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import WSU_Enrolment.DAO;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle.ComponentPlacement;

public class menu extends JFrame {

	// Variables declaration
	private JPanel contentPane;
	private JTextField textField;
    private String complete;
    private String username;
    private String newMsgs;
	
    // Constructor
	public menu(String usuername) {
        this.username=usuername;
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        updateLoginDate();
    }

    public void updateLoginDate() {
        DAO dao = new DAO();
        Date now = new Date();
        String format = "yyyy/MM/dd";
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        try {
            dao.connect();
            dao.executeSQL("UPDATE User_WSU SET lastLogin='"+formatter.format(now)+"' WHERE username='"+this.username+"'");
            dao.closeConnection();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
    
    public void numberMsgNRead(JTextField number, JLabel msgs) {
        int newMsgs = 0;
        DAO dao = new DAO();
        ResultSet rt = null;
        try {
            dao.connect();
            rt = dao.getResultSet("SELECT * FROM Messages_WSU WHERE username='"+this.username+"' AND lida='0'");
            while(rt.next()){
                newMsgs=newMsgs+1;
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        if (newMsgs == 1){
            msgs.setText("UNREAD MESSAGE");
        }
        number.setText(""+newMsgs+"");
    }

	/**
	 * Create the frame.
	 */
	public void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 562);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel label = new JLabel();
		label.setText("UNREAD MESSAGES");
		label.setBounds(438, 503, 151, 16);
		contentPane.add(label);
		
		textField = new JTextField();
		numberMsgNRead(textField, label);
		textField.setText("0");
		textField.setBounds(404, 498, 28, 26);
		contentPane.add(textField);
		
		JLabel label_1 = new JLabel();
		label_1.setText("YOU HAVE");
		label_1.setBounds(333, 503, 65, 16);
		contentPane.add(label_1);
		
		JToggleButton toggleButton = new JToggleButton();
		toggleButton.setText("READ MESSAGES");
		toggleButton.setBounds(595, 498, 147, 29);
		contentPane.add(toggleButton);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(778, 478));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 778, 478);
		contentPane.add(panel);
		 
		 JLabel label_2 = new JLabel();
		label_2.setText("MENU");
		label_2.setFont(new Font("Dialog", Font.PLAIN, 36));
		
		JLabel label_3 = new JLabel("Student board");
		label_3.setForeground(new Color(0, 0, 139));
		label_3.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JLabel label_4 = new JLabel("Events / NEWS");
		label_4.setForeground(new Color(0, 0, 128));
		label_4.setFont(new Font("Lucida Grande", Font.ITALIC, 16));
		
		JLabel label_5 = new JLabel();
		label_5.setText("WELCOME");
		label_5.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		
		JLabel label_6 = new JLabel("New label");
		label_6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label_6.setText(username.toUpperCase());
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		
		JButton button = new JButton();
		button.setText("LOGOUT");
		
		JButton button_1 = new JButton("Profile");
		
		JButton button_2 = new JButton("Grades");
		
		JButton button_3 = new JButton("Enroll");
		
		JButton button_4 = new JButton("News");
		
		JButton button_5 = new JButton("Calendar");
		 
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		JTextPane textPane_2 = new JTextPane();
		textPane_2.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
							.addGroup(gl_panel.createSequentialGroup()
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE)
								.addGap(79)
								.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))
							.addGroup(gl_panel.createSequentialGroup()
								.addComponent(label_5)
								.addGap(18)
								.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE)
								.addGap(385)
								.addComponent(button)))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(button_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(button_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(button_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(button_4, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(button_5, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(30)
							.addComponent(textPane, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)
							.addGap(43)
							.addComponent(textPane_2, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)))
					.addGap(43))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(30)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE, false)
						.addComponent(label_5)
						.addComponent(button)
						.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
					.addGap(16)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_2)
							.addComponent(label_3))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(18)
							.addComponent(button_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_2)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_3)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_4)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(button_5))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(6)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(textPane_2, GroupLayout.DEFAULT_SIZE, 335, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.RELATED))
								.addComponent(textPane, GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE))))
					.addGap(21))
		);
		panel.setLayout(gl_panel);
	}
}
