/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package WSU_Enrolment;

import java.sql.ResultSet;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Aldir Jr
 */

public class user {

    private String username;
    private String password;
    private String name;
    private String surname;
    private String situation;
    private String position;
    private int age;
    private String profile;

    public user(String username, String password, String name, String sobrenome, String situacao, String posicao, String profile){
        this.username=username;
        this.password=password;
        this.name=name;
        this.surname=sobrenome;
        this.situation=situacao;
        this.position=posicao;
        this.profile=profile;
    }

    public user(String username){
        this.username=username;
        int dia = 0,mes = 0,ano = 0;
        Date data;
        data = new Date();
        DAO dao = new DAO();
        ResultSet rs;
        try {
            dao.connect();
            rs = dao.getResultSet("SELECT day,month,year FROM Users_data WHERE username='"+this.username+"'");
            while(rs.next()){
                String diax = rs.getString("day");
                String mesx = rs.getString("month");
                String anox = rs.getString("year");
                dia = Integer.parseInt(diax);
                mes = Integer.parseInt(mesx);
                ano = Integer.parseInt(anox);
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        this.age = data.getYear() + 1900 - ano;
        if(mes > data.getMonth() + 1)
            this.age = this.age-1;
        else
            if(mes == data.getMonth() + 1)
                if (dia > data.getDate())
                    this.age = this.age-1;
    }

    /*
    public user(String user, String password){
        this.usuario=user;
        this.senha=password;
    }
    */

    public String getUsername(){
        return this.username;
    }

    public String getPassword(){
        return this.password;
    }

    public String getName(){
        return this.name;
    }

    public String getSurname(){
        return this.surname;
    }

    public String getSituation(){
        return this.situation;
    }

    public String getPosition(){
        return this.position;
    }

    public String getProfile(){
        return this.profile;
    }

    public int getAge(){
        return this.age;
    }

    public static List getUsers(){
        DAO dao = new DAO();
        List l = new LinkedList();
        ResultSet rs;
        try {
            dao.connect();
            rs = dao.getResultSet("SELECT username, password, name, surname, situation, position, profile FROM User_WSU ORDER BY username ASC");
            while(rs.next()){
                user u = new user(rs.getString("username"),rs.getString("password"),rs.getString("name"),rs.getString("surname"),rs.getString("situation"),rs.getString("position"),rs.getString("profile"));
                l.add(u);
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        return l;
    }

/*
    public static List getUsuarios(){
        DAO dao = new DAO();
        List l = new LinkedList();
        ResultSet rs;
        try {
            dao.conectar();
            rs = dao.getResultSet("SELECT user,password FROM user ORDER BY user ASC");
            while(rs.next()){
                user u = new user(rs.getString("user"),rs.getString("password"));
                l.add(u);
            }
            dao.fecharConexao();
        }catch (Exception e){
            e.printStackTrace();
        }
        return l;
    }
 */
}