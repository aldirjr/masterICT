/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package WSU_Enrolment;

import java.sql.ResultSet;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Aldir Jr
 */

public class user {

    private String username;
    private String password;
    private String name;
    private String surname;
    private int age;
    private String profile;

    public user(String username, String password, String name, String sobrenome, String profile){
        this.username=username;
        this.password=password;
        this.name=name;
        this.surname=sobrenome;
        this.profile=profile;
    }

    public user(String username){
        this.username=username;
        int day = 0,month = 0,year = 0;
        Date data;
        data = new Date();
        DAO dao = new DAO();
        ResultSet rs;
        try {
            dao.connect();
            rs = dao.getResultSet("SELECT day,month,year FROM ESU_User_data WHERE username='"+this.username+"'");
            while(rs.next()){
                String dayx = rs.getString("day");
                String monthx = rs.getString("month");
                String yearx = rs.getString("year");
                day = Integer.parseInt(dayx);
                month = Integer.parseInt(monthx);
                year = Integer.parseInt(yearx);
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        this.age = data.getYear() + 1900 - year;
        if(month > data.getMonth() + 1)
            this.age = this.age-1;
        else
            if(month == data.getMonth() + 1)
                if (day > data.getDate())
                    this.age = this.age-1;
    }

    /*
    public user(String user, String password){
        this.usuario=user;
        this.senha=password;
    }
    */

    public String getUsername(){
        return this.username;
    }

    public String getPassword(){
        return this.password;
    }

    public String getName(){
        return this.name;
    }

    public String getSurname(){
        return this.surname;
    }

    public String getProfile(){
        return this.profile;
    }

    public int getAge(){
        return this.age;
    }

    public static boolean confirmLogin(String login, String password){
        DAO dao = new DAO();
        ResultSet passwordFromSQL;
        try {
            dao.connect();
            passwordFromSQL = dao.getResultSet("SELECT password FROM ESU_User WHERE username = '"+login+"'");
            if (passwordFromSQL.next()) {
            	if (passwordFromSQL.getString("password").equalsIgnoreCase(password)) {

            		return true;
            	}
            	else {

            		return false;
            	}
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;  
    }
    
}