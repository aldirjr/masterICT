/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package WSU_Enrolment;

import java.sql.ResultSet;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Aldir Jr
 */

public class user {

    private String username;
    private String password;
    private String name;
    private String surname;
    private String situation;
    private String position;
    private int age;
    private String profile;

    public user(String username, String password, String name, String sobrenome, String situacao, String posicao, String profile){
        this.username=username;
        this.password=password;
        this.name=name;
        this.surname=sobrenome;
        this.situation=situacao;
        this.position=posicao;
        this.profile=profile;
    }

    public user(String username){
        this.username=username;
        int dia = 0,mes = 0,ano = 0;
        Date data;
        data = new Date();
        DAO dao = new DAO();
        ResultSet rs;
        try {
            dao.connect();
            rs = dao.getResultSet("SELECT day,month,year FROM Users_data WHERE username='"+this.username+"'");
            while(rs.next()){
                String diax = rs.getString("day");
                String mesx = rs.getString("month");
                String anox = rs.getString("year");
                dia = Integer.parseInt(diax);
                mes = Integer.parseInt(mesx);
                ano = Integer.parseInt(anox);
            }
            dao.closeConnection();
        }catch (Exception e){
            e.printStackTrace();
        }
        this.age = data.getYear() + 1900 - ano;
        if(mes > data.getMonth() + 1)
            this.age = this.age-1;
        else
            if(mes == data.getMonth() + 1)
                if (dia > data.getDate())
                    this.age = this.age-1;
    }

    /*
    public user(String user, String password){
        this.usuario=user;
        this.senha=password;
    }
    */

    public String getUsername(){
        return this.username;
    }

    public String getPassword(){
        return this.password;
    }

    public String getName(){
        return this.name;
    }

    public String getSurname(){
        return this.surname;
    }

    public String getSituation(){
        return this.situation;
    }

    public String getPosition(){
        return this.position;
    }

    public String getProfile(){
        return this.profile;
    }

    public int getAge(){
        return this.age;
    }

    public static boolean confirmLogin(String login, String password){
        DAO dao = new DAO();
        ResultSet passwordFromSQL;
        try {
            dao.connect();
            passwordFromSQL = dao.getResultSet("SELECT password FROM User_WSU WHERE username = '"+login+"'");
            if (passwordFromSQL.next()) {
            	System.out.println(passwordFromSQL.getString("password"));
            	if (passwordFromSQL.getString("password").equalsIgnoreCase(password)) {

            		return true;
            	}
            	else {

            		return false;
            	}
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;  
    }
    
}